/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import com.ibm.as400.access.*;

/**
 *
 * @author Sreejith Unnikrishnan
 */
public class DatabaseFetch {
    final String url = "jdbc:as400://174.79.32.158;prompt=false;user=%s;password=%s;";
	final String user="IBM57";
    final String password = "IBM57";
    final String DB_URL = String.format(url,user,password);
    
    
	
	public String[] question(String table,String questionNum)throws SQLException{
			String[] query = new String[6];
			System.out.println("Inside data base fetch");
                        //  ResultSet result=null;
			
			// Load the AS400JDBCDriver into memory so that DriverManager finds it
            try {
            	System.out.println("Inside database");
                Class.forName("com.ibm.as400.access.AS400JDBCDriver");
            } catch (ClassNotFoundException ex) {
                System.err.println("JDBC Driver Not Found.");
            }
			try{
				Connection conn = DriverManager.getConnection(DB_URL);
				System.out.println("Connection obtained");
				Statement stat = conn.createStatement();
				System.out.println("Inside data base fetch try");
				String sqlStatement = "select qst_no,question,option1,option2,option3,option4,answer from "+table+" where qst_no='"+questionNum+"'";
			        ResultSet result = stat.executeQuery(sqlStatement);
				if(result.next()){
					query[0] = result.getString("question");
					query[1] = result.getString("option1");
					query[2] = result.getString("option2");
					query[3] = result.getString("option3");
					query[4] = result.getString("option4");
					query[5] = result.getString("answer");
				}
				System.out.println(query[0]);
				conn.close();
				return query;
			}
			catch(Exception ex)
			{
				System.out.println("Error in connection: "+ex.getMessage());
                                return query;
			}
			
		}
        public String[] login(String userid,String password){
		String[] user = new String[3];
		try {
        	System.out.println("Inside database");
            Class.forName("com.ibm.as400.access.AS400JDBCDriver");
        } catch (ClassNotFoundException ex) {
            System.err.println("JDBC Driver Not Found.");
        }
		try{
			Connection conn = DriverManager.getConnection(DB_URL);
			System.out.println("Connection obtained");
			Statement stat = conn.createStatement();
			String sqlStatement = "select user_id,first_name,last_name from login where user_id= '"+userid+"' and password= '"+password+"'";
			ResultSet result = stat.executeQuery(sqlStatement);
			if(result.next()){
				user[0] = result.getString("user_id");
				user[1] = result.getString("first_name");
				user[2] = result.getString("last_name");
				
			}
			conn.close();
			return user;
		}
		catch(Exception ex)
		{
			System.out.println("Error in connection: "+ex.getMessage());
		}
		return user;
		
	}
	
	public boolean userIdFecth(String userid){
		 try {
         	System.out.println("Inside database");
             Class.forName("com.ibm.as400.access.AS400JDBCDriver");
         } catch (ClassNotFoundException ex) {
             System.err.println("JDBC Driver Not Found.");
         }
		try{
			Connection conn = DriverManager.getConnection(DB_URL);
			System.out.println("Connection obtained");
			Statement stat = conn.createStatement();
			String sqlStatement = "select user_id from login where user_id= '"+userid+"'";
			ResultSet result = stat.executeQuery(sqlStatement);
			if(result.next()){
				conn.close();
				return true;
			}
			else{
				conn.close();
				return false;
			}
			
			
		}
		catch(Exception ex)
		{
			System.out.println("Error in connection: "+ex.getMessage());
			return false;
		}
		
	}
	
	public boolean loginInsert(String userid,String first,String last,String password){
		 try {
         	System.out.println("Inside database");
             Class.forName("com.ibm.as400.access.AS400JDBCDriver");
         } catch (ClassNotFoundException ex) {
             System.err.println("JDBC Driver Not Found.");
         }
		try{
			Connection conn = DriverManager.getConnection(DB_URL);
			System.out.println("Connection obtained");
			Statement stat = conn.createStatement();
			String sqlStatement = "insert into login values ('"+userid+"','"+first+"','"+last+"','"+password+"')";
			int result = stat.executeUpdate(sqlStatement);
			if(result > 0){
				conn.close();
				return true;
			}
			else{
				conn.close();
				return false;
			}
			
			
		}
		catch(Exception ex)
		{
			System.out.println("Error : "+ex.getMessage());
			return false;
		}
		
	}
    
}
