/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.SQLException;

/**
 *
 * @author Sreejith Unnikrishnan
 */
public class Quiz {
     
    private String qst;
	private String option1;
	private String option2;
	private String option3;
	private String option4;
	private String answer;
	private String table;
	private String[] qstFetch = new String[6];
	private int amount[] = {1000,2000,3000,5000,10000,20000,40000,80000,160000,320000,625000,1250000,2500000,5000000,10000000};
	private int userProgress = 1;
	private String selected;
	private int amountWon = 0;
	private int savedamount = 0;
	private String message;
	private String msg[] = new String[2];
	
	
	
	
	public String getQst() {
		return qst;
	}


	public void setQst(String qst) {
		this.qst = qst;
	}


	public String getOption1() {
		return option1;
	}


	public void setOption1(String option1) {
		this.option1 = option1;
	}


	public String getOption2() {
		return option2;
	}


	public void setOption2(String option2) {
		this.option2 = option2;
	}


	public String getOption3() {
		return option3;
	}


	public void setOption3(String option3) {
		this.option3 = option3;
	}


	public String getOption4() {
		return option4;
	}


	public void setOption4(String option4) {
		this.option4 = option4;
	}


	public String getAnswer() {
		return answer;
	}


	public void setAnswer(String answer) {
		this.answer = answer;
	}


	public String getTable() {
		return table;
	}


	public void setTable(String table) {
		this.table = table;
	}


	public String getSelected() {
		return selected;
	}


	public void setSelected(String selected) {
		this.selected = selected;
	}
	
	

	public int[] getAmount() {
		return amount;
	}


	public void setAmount(int[] amount) {
		this.amount = amount;
	}


	public int getUserProgress() {
		return userProgress;
	}


	public void setUserProgress(int userProgress) {
		this.userProgress = userProgress;
	}


	public int getAmountWon() {
		return amountWon;
	}


	public void setAmountWon(int amountWon) {
		this.amountWon = amountWon;
	}


	public int getSavedamount() {
		return savedamount;
	}


	public void setSavedamount(int savedamount) {
		this.savedamount = savedamount;
	}


	public String getMessage() {
		return message;
	}


	public void setMessage(String message) {
		this.message = message;
	}


	public void showQuestion(int qnsNum) throws SQLException{
		FetchQuestion qst = new FetchQuestion();
		if(qnsNum <= 5){
			System.out.println("inside show questionh"+qnsNum);
			table = "simple_question";
			System.out.println(table);
			qstFetch = qst.questionFetch(table).clone();
			//userProgress++;
			this.qst = qstFetch[0];
			System.out.println(qst);
			this.option1 = qstFetch[1];
			this.option2 = qstFetch[2];
			this.option3 = qstFetch[3];
			this.option4 = qstFetch[4];
			//this.answer = qstFetch[5];
			this.setAnswer(qstFetch[5]);
			System.out.println(option1);
			System.out.println(option2);
			System.out.println(option3);
			System.out.println(option4);
			System.out.println(answer);
			
			//return qstFetch;
		}
		else if(qnsNum >5 && qnsNum <= 10){
			table = "medium_question";
			qstFetch = qst.questionFetch(table).clone();
			//userProgress++;
			this.qst = qstFetch[0];
			this.option1 = qstFetch[1];
			this.option2 = qstFetch[2];
			this.option3 = qstFetch[3];
			this.option4 = qstFetch[4];
			this.answer = qstFetch[5];
			//return qstFetch;
		}
		else{
			table = "difficult_question";
			qstFetch = qst.questionFetch(table).clone();
			//userProgress++;
			this.qst = qstFetch[0];
			this.option1 = qstFetch[1];
			this.option2 = qstFetch[2];
			this.option3 = qstFetch[3];
			this.option4 = qstFetch[4];
			this.answer = qstFetch[5];
			//return qstFetch;
		}
		
	}
	
	public String[] checkAnswer(String select,String ans,int progress){
		//this.selected = select;
		select = select.trim();
		ans = ans.trim();
		/*progress = progress.trim();
		int userpro = Integer.parseInt(progress);*/
		System.out.println("Inside Check Answer");
		System.out.println("Selected:"+select.length());
		System.out.println("original:"+ans.length());
		if(select.equalsIgnoreCase(ans))
			{
			System.out.println("true in if statement");
			amountWon = amount[progress-1];
			System.out.println("Amount Won:"+amountWon);
			if(amountWon >= 10000 && amountWon < 320000){
				savedamount = 10000;
			}
			else if(amountWon >= 320000 && amountWon < 10000000){
				savedamount = 320000;
			}
			if(savedamount == 10000000){
				message = "User have Won $"+savedamount+"\nCongrats You have completed the game!!!";
				//userProgress++;
				msg[0]= "false";
				msg[1] = message;
				return msg;
			}
			else{
				message = "You have selected the correct answer!!! Congrats you Won $"+amountWon;
				userProgress++;
				msg[0]= "true";
				msg[1] = message;
				return msg;
				
			}
		}
		else{
			System.out.println("false in if statement");
			amountWon = amount[progress-2];
			if(amountWon >= 10000 && amountWon < 320000){
				savedamount = 10000;
			}
			else if(amountWon >= 320000 && amountWon < 10000000){
				savedamount = 320000;
			}
			if(savedamount >=10000){
				message = "You have selected the Wrong answer!!! You have Won $"+savedamount;
				System.out.println(message);
				msg[0]= "false";
				msg[1] = message;
				return msg;
			}
			else{
				message = "You have selected the Wrong answer!!! Better luck next time!!";
				System.out.println(message);
				msg[0]= "false";
				msg[1] = message;
				return msg;
			}
			
		}
	}
	/*public void quiz() throws SQLException{
		do{
			//showQuestion();
			if(checkAnswer(this.selected)){
				amountWon = amount[userProgress-1];
				if(amountWon == 10000 || amountWon == 320000 || amountWon == 10000000){
					savedamount = amountWon;
				}
				message = "You have selected the correct answer!!! Congrats you Won $"+amountWon;
				userProgress++;
			}
			else{
				message = "You have selected the Worng answer!!!";
			}
			
		}while(checkAnswer(selected) && userProgress <= 15);
		if(savedamount == 10000000){
			message = "User have Won $"+savedamount+"\nCongrats You have completed the game!!!";
		}
		else if(savedamount > 0){
			message = "User have Won $"+savedamount+" Congrats!!!";
		}
		else{
			message = "Please Try Again!!!";
		}
	}*/
}
